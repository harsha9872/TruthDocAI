import os
import re
import threading
import uvicorn
import docx
import pytesseract
from typing import List, Tuple
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from PIL import Image
from pdf2image import convert_from_path

# Kivy imports and styling
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.filechooser import FileChooserIconView
from kivy.uix.popup import Popup
from kivy.uix.image import Image
from kivy.uix.progressbar import ProgressBar
from kivy.lang import Builder

# some basic style rules
Builder.load_string(r"""
<RootWidget>:
    canvas.before:
        Color:
            rgba: 0.12,0.12,0.12,1
        Rectangle:
            pos: self.pos
            size: self.size

<Button>:
    background_color: (.2,.2,.2,1)
    color: (1,1,1,1)
    font_size: '18sp'

<Label>:
    color: (1,1,1,1)
    font_size: '16sp'

<TextInput>:
    background_color: (1,1,1,1)
    foreground_color: (0,0,0,1)
    font_size: '16sp'
"""
)

import requests

# set Tesseract windows path if needed
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# backend URL (same process will host API on 8000)
BACKEND_URL = "http://127.0.0.1:8000"  # will be updated at runtime to use a free port

# ----------- FastAPI backend setup -----------
app = FastAPI(title="TruthDoc AI", description="Smart Document Fraud Detection API")

# helper functions (extracted from main.py)
def extract_text_from_image(file: UploadFile) -> str:
    try:
        image = Image.open(file.file)
        return pytesseract.image_to_string(image)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Image processing failed: {str(e)}")

def extract_text_from_pdf(file: UploadFile) -> str:
    try:
        temp_path = f"temp_{file.filename}"
        with open(temp_path, "wb") as f:
            f.write(file.file.read())
        pages = convert_from_path(temp_path)
        text = ""
        for page in pages:
            text += pytesseract.image_to_string(page)
        os.remove(temp_path)
        return text
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"PDF processing failed: {str(e)}")

def extract_text_from_docx(file: UploadFile) -> str:
    try:
        temp_path = f"temp_{file.filename}"
        with open(temp_path, "wb") as f:
            f.write(file.file.read())
        doc = docx.Document(temp_path)
        text = "\n".join([para.text for para in doc.paragraphs])
        os.remove(temp_path)
        return text
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"DOCX processing failed: {str(e)}")

def analyze_document(text: str) -> Tuple[str, int, List[str]]:
    flags: List[str] = []
    risk_score = 0
    if not re.search(r"(Dr\.|Doctor|Company|Inc|Ltd|Registration\s*No)", text, re.IGNORECASE):
        flags.append("Missing entity details (Doctor/Company/Registration Number)")
        risk_score += 20
    if re.search(r"common cold", text, re.IGNORECASE):
        match = re.search(r"(\d+)\s*days", text)
        if match and int(match.group(1)) > 5:
            flags.append("Unrealistic leave duration for minor illness")
            risk_score += 30
    suspicious_keywords = ["Sample", "Draft", "Specimen", "Confidential"]
    for keyword in suspicious_keywords:
        if re.search(keyword, text, re.IGNORECASE):
            flags.append(f"Contains suspicious keyword: {keyword}")
            risk_score += 25
    status = "Suspicious" if risk_score > 40 else "Genuine"
    return status, min(risk_score, 100), flags

def analyze_sms(text: str) -> Tuple[str, int, List[str]]:
    flags: List[str] = []
    risk_score = 0
    urgency_flags = ["Hurry up", "slots open", "limited time", "immediate joining"]
    platform_flags = ["Google Form", "WhatsApp only"]
    fraud_flags = ["Security deposit", "Pay for training", "No interview"]
    for keyword in urgency_flags + platform_flags:
        if re.search(keyword, text, re.IGNORECASE):
            flags.append(f"Urgency/Platform flag: {keyword}")
            risk_score += 25
    for keyword in fraud_flags:
        if re.search(keyword, text, re.IGNORECASE):
            flags.append(f"Fraud flag: {keyword}")
            risk_score += 30
    if re.search(r"https?://", text):
        flags.append("Contains suspicious URL")
        risk_score += 30
    status = "Suspicious" if risk_score > 40 else "Genuine"
    return status, min(risk_score, 100), flags

class SMSInput(BaseModel):
    raw_text: str

@app.post("/verify-document/")
async def verify_document(file: UploadFile = File(...)):
    try:
        filename_lower = file.filename.lower()
        if filename_lower.endswith((".png", ".jpg", ".jpeg")):
            text = extract_text_from_image(file)
        elif filename_lower.endswith(".pdf"):
            text = extract_text_from_pdf(file)
        elif filename_lower.endswith(".docx"):
            text = extract_text_from_docx(file)
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")
        status, risk_score, flags = analyze_document(text)
        return JSONResponse(content={
            "filename": file.filename,
            "status": status,
            "risk_score": risk_score,
            "reason_for_flag": flags
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(e)}")

@app.post("/verify-sms/")
async def verify_sms(input_data: SMSInput):
    try:
        status, risk_score, flags = analyze_sms(input_data.raw_text)
        return JSONResponse(content={
            "filename": "raw_text_input",
            "status": status,
            "risk_score": risk_score,
            "reason_for_flag": flags
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"SMS verification failed: {str(e)}")

# utility to test if a port is free
import socket

def _is_port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        # connect_ex returns 0 if the port is open (in use)
        return s.connect_ex(("127.0.0.1", port)) != 0


def find_free_port(start: int = 8000, end: int = 8100) -> int:
    """Return a free TCP port between start and end (inclusive)."""
    for p in range(start, end + 1):
        if _is_port_free(p):
            return p
    raise RuntimeError("no free port available")

# function to run uvicorn server in background
def _run_api(port: int):
    try:
        uvicorn.run(app, host="0.0.0.0", port=port)
    except Exception as e:
        # log and continue; don't crash the GUI
        print(f"[backend] failed to start on port {port}: {e}")



class RootWidget(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", spacing=10, padding=10, **kwargs)
        self.file_path = ""                    # currently selected document

        # title at top
        self.add_widget(Label(text="📄 TruthDoc AI", font_size='24sp', size_hint=(1, 0.1)))

        # selection info and buttons grouped
        doc_box = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1,0.1))
        self.selected_label = Label(text="No file selected", size_hint=(0.6,1))
        self.doc_select = Button(text="Browse…", size_hint=(0.2,1))
        self.doc_select.bind(on_press=self.open_filechooser)
        self.verify_button = Button(text="Verify", size_hint=(0.2,1))
        self.verify_button.bind(on_press=self.verify_document)
        doc_box.add_widget(self.selected_label)
        doc_box.add_widget(self.doc_select)
        doc_box.add_widget(self.verify_button)
        self.add_widget(doc_box)

        # preview area
        self.preview = Image(size_hint=(1, 0.3))
        self.add_widget(self.preview)

        # sms input area grouped
        sms_box = BoxLayout(orientation='vertical', spacing=5, size_hint=(1,0.3))
        self.sms_input = TextInput(hint_text="Paste SMS/Internship message here",
                                   size_hint=(1, 0.75), multiline=True)
        sms_box.add_widget(self.sms_input)
        self.sms_button = Button(text="Verify SMS", size_hint=(1, 0.25))
        self.sms_button.bind(on_press=self.verify_sms)
        sms_box.add_widget(self.sms_button)
        self.add_widget(sms_box)

        # result display
        self.result_label = Label(text="", size_hint=(1, 0.2))
        self.add_widget(self.result_label)
        self.progress = ProgressBar(max=100, value=0, size_hint=(1,0.05))
        self.add_widget(self.progress)

    def verify_document(self, instance):
        if not self.file_path:
            self.result_label.text = "⚠️ Select a file first"
            return
        # clear previous result (but keep selected label)
        self.result_label.text = ""
        self.result_label.color = (1,1,1,1)
        self.progress.value = 0
        path = self.file_path
        try:
            with open(path, 'rb') as f:
                files = {'file': (os.path.basename(path), f, 'application/octet-stream')}
                try:
                    response = requests.post(f"{BACKEND_URL}/verify-document/", files=files)
                except requests.exceptions.RequestException as re:
                    self.result_label.text = f"⚠️ Backend request failed: {re}"
                    return
            if response.status_code == 200:
                data = response.json()
                # nicely format the result
                lines = [f"Status: {data['status']}",
                         f"Risk score: {data['risk_score']}%"]
                if data['reason_for_flag']:
                    lines.append("Reasons:")
                    for r in data['reason_for_flag']:
                        lines.append(f" - {r}")
                self.result_label.text = "\n".join(lines)
                # color-code
                if data['status'].lower() == "genuine":
                    self.result_label.color = (0,1,0,1)
                else:
                    self.result_label.color = (1,0,0,1)
                try:
                    self.progress.value = int(data['risk_score'])
                except Exception:
                    self.progress.value = 0
            else:
                self.result_label.text = "❌ Backend error"
        except Exception as e:
            self.result_label.text = f"⚠️ {str(e)}"

    def verify_sms(self, instance):
        text = self.sms_input.text.strip()
        if not text:
            self.result_label.text = "⚠️ Enter some text"
            return
        # reset previous
        self.result_label.text = ""
        self.result_label.color = (1,1,1,1)
        self.progress.value = 0
        try:
            payload = {"raw_text": text}
            try:
                response = requests.post(f"{BACKEND_URL}/verify-sms/", json=payload)
            except requests.exceptions.RequestException as re:
                self.result_label.text = f"⚠️ Backend request failed: {re}"
                return
            if response.status_code == 200:
                data = response.json()
                lines = [f"Status: {data['status']}", f"Risk score: {data['risk_score']}%"]
                if data['reason_for_flag']:
                    lines.append("Reasons:")
                    for r in data['reason_for_flag']:
                        lines.append(f" - {r}")
                self.result_label.text = "\n".join(lines)
                if data['status'].lower() == "genuine":
                    self.result_label.color = (0,1,0,1)
                else:
                    self.result_label.color = (1,0,0,1)
                try:
                    self.progress.value = int(data['risk_score'])
                except Exception:
                    self.progress.value = 0
            else:
                self.result_label.text = "❌ Backend error"
        except Exception as e:
            self.result_label.text = f"⚠️ {str(e)}"

    # method moved from TruthDocApp below
    def open_filechooser(self, instance):
        # popup with file chooser so the main UI isn't flooded
        content = BoxLayout(orientation='vertical')
        fc = FileChooserIconView(filters=['*.png','*.jpg','*.jpeg','*.pdf','*.docx'],
                                 size_hint=(1,0.9))
        # start browsing in home directory rather than root
        try:
            fc.path = os.path.expanduser('~')
        except Exception:
            pass
        btn = Button(text='Select', size_hint=(1,0.1))
        content.add_widget(fc)
        content.add_widget(btn)
        popup = Popup(title='Pick a file', content=content, size_hint=(0.9,0.9))

        def choose(_):
            if fc.selection:
                self.file_path = fc.selection[0]
                popup.dismiss()
                # display selection in separate label
                self.selected_label.text = f"Selected: {os.path.basename(self.file_path)}"
                # preview if image
                if self.file_path.lower().endswith(('.png', '.jpg', '.jpeg')):
                    self.preview.source = self.file_path
                else:
                    self.preview.source = ''
        btn.bind(on_press=choose)
        popup.open()


class TruthDocApp(App):
    def build(self):
        # optional: set window title & size
        self.title = "TruthDoc AI"
        return RootWidget()



if __name__ == "__main__":
    # choose a free port for backend
    try:
        port = find_free_port(8000, 8099)
        BACKEND_URL = f"http://127.0.0.1:{port}"
        api_thread = threading.Thread(target=_run_api, args=(port,), daemon=True)
        api_thread.start()
        print(f"[backend] starting on port {port}")
    except Exception as e:
        print(f"[backend] failed to allocate port: {e}")
    # launch the Kivy frontend
    TruthDocApp().run()
