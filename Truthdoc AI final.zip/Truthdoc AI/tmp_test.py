import traceback
from pdf2image import convert_from_path

try:
    pages=convert_from_path(r'c:\Users\harsh\OneDrive\Documents\Truthdoc AI\Truthdoc AI\temp_pranee 10th.pdf')
    print('converted', len(pages))
except Exception as e:
    traceback.print_exc()
